const config = require('./settings/config');
const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const crypto  = require("crypto")
const fetch = require("node-fetch")
const { tiktokscrape } = require('./w-shennmine/lib/allscrape')
const moment = require("moment-timezone");
const { generateWAMessageFromContent } = require('@shennmine/baileys')
const { downloadMediaMessage } = require('@shennmine/baileys');
const path = require("path")
const os = require('os');
const speed = require('performance-now')
const { spawn, exec, execSync } = require('child_process');
const { default: baileys, getContentType } = require("@shennmine/baileys");
module.exports = client = async (client, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId ||
            m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
        );
        
        const sender = m.key.fromMe ? client.user.id.split(":")[0] + "@s.whatsapp.net" ||
              client.user.id : m.key.participant || m.key.remoteJid;
        
        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = ["", "!", ".", ",", "🐤", "🗿"];

        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const botNumber = await client.decodeJid(client.user.id);
        const isBot = botNumber.includes(senderNumber)
        
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);
        
        const { smsg, fetchJson, sleep, formatSize, runtime } = require('./w-shennmine/lib/myfunction');     
        const cihuy = fs.readFileSync('./w-shennmine/lib/media/w-shennmine.jpg')
        const { fquoted } = require('./w-shennmine/lib/fquoted')

        // group
        const groupMetadata = m?.isGroup ? await client.groupMetadata(m.chat).catch(() => ({})) : {};
        const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
        const participants = m?.isGroup ? groupMetadata.participants?.map(p => {
            let admin = null;
            if (p.admin === 'superadmin') admin = 'superadmin';
            else if (p.admin === 'admin') admin = 'admin';
            return {
                id: p.id || null,
                jid: p.jid || null,
                admin,
                full: p
            };
        }) || []: [];
        const groupOwner = m?.isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
        const groupAdmins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid || p.id);
        const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = m?.isGroup ? groupAdmins.includes(m.sender) : false;
        const isGroupOwner = m?.isGroup ? groupOwner === m.sender : false;
        
        if (m.message) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#4a69bd").bold(`▢ New Message`));
            console.log(
                chalk.bgHex("#ffffff").black(
                    `   ▢ Tanggal: ${new Date().toLocaleString()} \n` +
                    `   ▢ Pesan: ${m.body || m.mtype} \n` +
                    `   ▢ Pengirim: ${pushname} \n` +
                    `   ▢ JID: ${senderNumber} \n`
                )
            );
            console.log();
        }
        
        const reaction = async (jidss, emoji) => {
            client.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key 
                } 
            })
        };
        
        async function reply(text) {
            client.sendMessage(m.chat, {
                text: "\n" + text + "\n",
                contextInfo: {
                    mentionedJid: [sender],
                    externalAdReply: {
                        title: config.settings.title,
                        body: config.settings.description,
                        thumbnailUrl: config.thumbUrl,
                        sourceUrl: config.socialMedia.Telegram,
                        renderLargerThumbnail: false,
                    }
                }
            }, { quoted: fquoted.packSticker })
        }
        
        
        async function uploadToCatbox(buffer) {
  try {
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, {
      filename: 'avatar.jpg',
      contentType: 'image/jpeg'
    })

    const res = await axios.post(
      'https://api.deline.web.id/M8TgbiUftL.jpg',
      form,
      { headers: form.getHeaders() }
    )

    if (typeof res.data === 'string' && res.data.startsWith('https://')) {
      return res.data
    }

    throw res.data
  } catch (e) {
    throw new Error('Upload Catbox gagal')
  }
}
        
        const pluginsLoader = async (directory) => {
            let plugins = [];
            const folders = fs.readdirSync(directory);
            folders.forEach(file => {
                const filePath = path.join(directory, file);
                if (filePath.endsWith(".js")) {
                    try {
                        const resolvedPath = require.resolve(filePath);
                        if (require.cache[resolvedPath]) {
                            delete require.cache[resolvedPath];
                        }
                        const plugin = require(filePath);
                        plugins.push(plugin);
                    } catch (error) {
                        console.log(`${filePath}:`, error);
                    }
                }
            });
            return plugins;
        };

        const pluginsDisable = true;
        const plugins = await pluginsLoader(path.resolve(__dirname, "./command"));
        const plug = {
            client,
            prefix,
            command, 
            reply, 
            text, 
            isBot,
            reaction,
            pushname, 
            mime,
            quoted,
            sleep,
            fquoted,
            fetchJson 
        };

        for (let plugin of plugins) {
            if (plugin.command.find(e => e == command.toLowerCase())) {
                if (plugin.isBot && !isBot) {
                    return
                }
                
                if (plugin.private && !plug.isPrivate) {
                    return m.reply(config.message.private);
                }

                if (typeof plugin !== "function") return;
                await plugin(m, plug);
            }
        }
        
        if (!pluginsDisable) return;  

        switch (command) {
            case "laurine":{
                
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const usedMem = totalMem - freeMem;
                const formattedUsedMem = formatSize(usedMem);
                const formattedTotalMem = formatSize(totalMem);
                let timestamp = speed()
                let latensi = speed() - timestamp
                let menu = `
 ▢ speed: ${latensi.toFixed(4)} s
 ▢ runtime: ${runtime(process.uptime())}
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}

command:
 ▢ ${prefix}tagall
 ▢ ${prefix}tt
 ▢ ${prefix}upswgc
 ▢ ${prefix}call
 ▢ ${prefix}get
 ▢ ${prefix}insp
 ▢ ${prefix}rvo
 ▢ ${prefix}quoted
 ▢ ${prefix}csesi
 ▢ ${prefix}exec
 ▢ ${prefix}eval
 ▢ ${prefix}mesinfo`
                    await client.sendMessage(m.chat, {
                        interactiveMessage: {
                            title: menu,
                            footer: config.settings.footer,
                            thumbnail: "https://api.deline.web.id/M8TgbiUftL.jpg",
                            nativeFlowMessage: {
                                messageParamsJson: JSON.stringify({
                                    limited_time_offer: {
                                        text: "shenń, yes",
                                        url: "t.me/..",
                                        copy_code: "shenń, yes",
                                        expiration_time: Date.now() * 999
                                    },
                                    bottom_sheet: {
                                        in_thread_buttons_limit: 2,
                                        divider_indices: [1, 2, 3, 4, 5, 999],
                                        list_title: "shennminè",
                                        button_title: "shenń"
                                    },
                                    tap_target_configuration: {
                                        title: "▸ X ◂",
                                        description: "bomboclard",
                                        canonical_url: "https://t.me/sh3nn",
                                        domain: "shop.example.com",
                                        button_index: 0
                                    }
                                }),
                                buttons: [
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
                                    },
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({
                                            title: "shennminè",
                                            sections: [
                                                {
                                                    title: "# X - the best",
                                                    highlight_label: "label",
                                                    rows: [
                                                        {
                                                            title: "Pikir dewe", 
                                                            description: "b!cth",
                                                            id: "row_1"
                                                        },
                                                        { 
                                                            title: "@renjii",
                                                            description: "sh3nnmine",
                                                            id: "row_2"
                                                        },
                                                        { 
                                                            title: "@Syzenn",
                                                            description: "rock and roll",
                                                            id: "row_3" 
                                                        }
                                                    ]
                                                }
                                            ],
                                            has_multiple_buttons: true
                                        })
                                    },
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "shennminè",
                                            id: "123456789",
                                            copy_code: "https://t.me/sh3n"
                                        })
                                    }
                                ]
                            }
                        }
                    }, { quoted: fquoted.packSticker });
            }
            break
            case "mesinfo": {
                if (!m.quoted) return reply("harap reply ke sebuah pesan untuk mengecek mtype dan id-nya.");
             
                const type = m.quoted.mtype;
                const id = m.quoted.id;
                reply(`Pesan yang di-reply memiliki:\n- Tipe pesan: *${type}*\n- ID pesan: *${id}*`);
            }
            break;
            case "get":{
                if (!isBot) return
                if (!/^https?:\/\//.test(text)) return reply(`*ex:* ${prefix + command} https://kyuurzy.site`);
                const ajg = await fetch(text);
                await reaction(m.chat, "⚡")
                
                if (ajg.headers.get("content-length") > 100 * 1024 * 1024) {
                    throw `Content-Length: ${ajg.headers.get("content-length")}`;
                }

                const contentType = ajg.headers.get("content-type");
                if (contentType.startsWith("image/")) {
                    return client.sendMessage(m.chat, {
                        image: { url: text }
                    }, { quoted: fquoted.packSticker });
                }
        
                if (contentType.startsWith("video/")) {
                    return client.sendMessage(m.chat, {
                        video: { url: text } 
                    }, { quoted: fquoted.packSticker });
                }
                
                if (contentType.startsWith("audio/")) {
                    return client.sendMessage(m.chat, {
                        audio: { url: text },
                        mimetype: 'audio/mpeg', 
                        ptt: true
                    }, { quoted: fquoted.packSticker });
                }
        
                let alak = await ajg.buffer();
                try {
                    alak = util.format(JSON.parse(alak + ""));
                } catch (e) {
                    alak = alak + "";
                } finally {
                    return reply(alak.slice(0, 65536));
                }
            }
            break
            
            case 'fakecall':
case 'call': {
  if (!text || !text.includes('|')) {
    return m.reply(
      `⚠️ Format salah!\n\n` +
      `${prefix + command} Nama|HH:MM:SS\n\n` +
      `Contoh:\n` +
      `${prefix + command} Boss|00:05:12`
    )
  }

  const [name, duration] = text.split('|').map(v => v.trim())
  if (!name || !duration) return m.reply('❌ Nama atau durasi tidak valid')

  const target = m.quoted ? m.quoted : m
  const mime = (target.msg || target).mimetype || ''

  if (!/image/.test(mime)) {
    return m.reply(
      `❌ Avatar tidak ditemukan\n\n` +
      `Gunakan sebagai caption foto atau reply foto`
    )
  }

  try {
    await m.react('📞')

    const mediaPath = await client.downloadAndSaveMediaMessage(target)
    const buffer = fs.readFileSync(mediaPath)
    fs.unlinkSync(mediaPath)

    const avatarUrl = await uploadToCatbox(buffer)


    const api = `https://velyn.mom/api/maker/calling`
    const { data } = await axios.get(api, {
      params: {
        apikey: global.velynApiKey,
        name,
        duration,
        avatar: avatarUrl
      }
    })

    if (!data.status || !data.result?.url) {
      return m.reply('❌ Gagal membuat fake call')
    }

    await client.sendMessage(
      m.chat,
      {
        image: { url: data.result.url },
        caption:
          `✅ Fake Call Berhasil!\n` +
          `👤 Nama: ${name}\n` +
          `⏱ Durasi: ${duration}`
      },
      { quoted: m }
    )

  } catch (err) {
    console.error('[FAKECALL ERROR]', err)
    m.reply('❌ Terjadi kesalahan saat memproses fake call')
  }
}
break
            
            
            case "insp": {
                if (!isBot) return
                if (!text && !m.quoted) return reply(`*reply:* ${prefix + command}`);
                let quotedType = m.quoted?.mtype || '';
                let penis = JSON.stringify({ [quotedType]: m.quoted }, null, 2);
                const acak = `insp-${crypto.randomBytes(6).toString('hex')}.json`;
                
                await client.sendMessage(m.chat, {
                    document: Buffer.from(penis),
                    fileName: acak,
                    mimetype: "application/json"
                }, { quoted: fquoted.packSticker })
            }
            break
            case "quoted": {
    if (!m.quoted) {
        return reply(`-Example: Reply Chat ${prefix + command}`)
    }

    await reply(config.message?.wait || "processing...")

    // ambil tipe quoted
    const quotedType = m.quoted.mtype

    // stringify quoted message
    const data = JSON.stringify(
        { [quotedType]: m.quoted },
        null,
        2
    )

    // nama file random biar aman
    const fileName = `quoted-${crypto.randomBytes(6).toString('hex')}.json`
    const filePath = path.join(__dirname, fileName)

    // simpan file
    fs.writeFileSync(filePath, data)

    // kirim text json (potong biar gak overlimit)
    await reply(data.slice(0, 65000))

    // kirim file json
    await client.sendMessage(
        m.chat,
        {
            document: fs.readFileSync(filePath),
            fileName: fileName,
            mimetype: "application/json"
        },
        { quoted: fquoted.packSticker }
    )

    // hapus file
    fs.unlinkSync(filePath)
}
break


            case 'tagall':{
                if (!isBot) return
                const textMessage = args.join(" ") || "nothing";
                let teks = `tagall message :\n> *${textMessage}*\n\n`;
                const groupMetadata = await client.groupMetadata(m.chat);
                const participants = groupMetadata.participants;
                for (let mem of participants) {
                    teks += `@${mem.id.split("@")[0]}\n`;
                }

                client.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map((a) => a.id)
                }, { quoted: fquoted.packSticker });
            }
            break
            
            case 'upswgc': {
  if (!m.quoted) return m.reply(`-Example: Reply Media ${prefix + command}`)

  try {
    // ambil isi media quoted
    const quotedType = m.quoted.mtype
    if (!quotedType) return m.reply('❌ Media tidak valid')

    const payload = {
      [quotedType]: m.quoted
    }

    // kirim ke group status
    await client.relayMessage(
      m.chat,
      {
        groupStatusMessageV2: {
          message: payload        }
      },
      {}
    )
      await m.reply('✅ *Done! Upsw*')

    m.reply(mess.success)
  } catch (err) {
    console.error('[UPSWGC ERROR]', err)
    m.reply(mess.error)
  }
}
break
            
            
            case "exec": {
                if (!isBot) return;
                if (!budy.startsWith(".exec")) return;
                
                const { exec } = require("child_process");
                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(`*ex:* ${prefix + command} ls`);
                exec(args, (err, stdout) => {
                    if (err) return reply(String(err));
                    if (stdout) return reply(stdout);
                });
            }
            break;
            case "eval": {
                if (!isBot) return;
                if (!budy.startsWith(".eval")) return;
                
                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(`*ex:* ${prefix + command} m.chat`);
                let teks;
                try {
                    teks = await eval(`(async () => { ${args.startsWith("return") ? "" : "return"} ${args} })()`);
                } catch (e) {
                    teks = e;
                } finally {
                    await reply(require('util').format(teks));
                }
            }
            break;
            
            case 'tt': {
    if (!text) return reply(`Example: ${prefix + command} link`)

    try {
        reply('⏳ Tunggu sebentar...')

        const data = await tiktokscrape(text)
        if (!data) return reply('❌ Gagal mengambil data TikTok')

        const { type, videoBuffer, audioBuffer, imageBuffers, meta } = data

        const caption = `
⌗ TikTok Post Info
Type: ${meta.type || '-'}
Author: ${meta.author?.nickname || meta.author?.username || '-'}
Likes: ${meta.stats?.likes || 0}
Comments: ${meta.stats?.comment || 0}
Shares: ${meta.stats?.share || 0}
Views: ${meta.stats?.views || 0}
Caption: ${meta.desc || '-'}
Music: ${meta.music?.title || '-'} ${meta.music?.author ? '-' + meta.music.author : ''}
`.trim()

        if (type === 'image' && imageBuffers?.length) {
            for (let i = 0; i < imageBuffers.length; i++) {
                await client.sendMessage(
                    m.chat,
                    { image: imageBuffers[i], caption: i === 0 ? caption : '' },
                    { quoted: m }
                )
            }
        } else {
            await client.sendMessage(
                m.chat,
                { video: videoBuffer, caption },
                { quoted: m }
            )
        }

        if (audioBuffer) {
            await client.sendMessage(
                m.chat,
                { audio: audioBuffer, mimetype: 'audio/mpeg' },
                { quoted: m }
            )
        }

    } catch (e) {
        console.error('[TIKTOK ERROR]', e)
        reply('❌ Terjadi error')
    }

    break
}
            
            case 'rvo': {
    if (!m.quoted) {
        return reply(`-Example: Reply Media ${prefix + command}`)
    }

    try {
        let mediaObj = { ...m.quoted }

        // === FIX PENTING ===
        if (!mediaObj.caption) mediaObj.caption = ''

        delete mediaObj.viewOnce

        const msg = generateWAMessageFromContent(
            m.chat,
            { [m.quoted.mtype]: mediaObj },
            { quoted: m }
        )

        await client.relayMessage(
            m.chat,
            msg.message,
            { messageId: msg.key.id }
        )
        
        await m.reply('🔓*Unlock*')

    } catch (err) {
        console.error('[RVO ERROR]', err)
        reply('❌ Gagal membuka View Once')
    }

    break
}
            
         case 'ping':
case 'botstatus':
case 'statusbot': {
    if (!isBot) return
    if (!budy.startsWith(prefix)) return

    const used = process.memoryUsage()

    const cpus = os.cpus().map(cpu => {
        cpu.total = Object.values(cpu.times).reduce((a, b) => a + b, 0)
        return cpu
    })

    const cpu = cpus.reduce((last, cpu, _, { length }) => {
        last.total += cpu.total
        last.speed += cpu.speed / length
        for (let type in cpu.times) {
            last.times[type] += cpu.times[type]
        }
        return last
    }, {
        speed: 0,
        total: 0,
        times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 }
    })

    const start = speed()
    const latency = speed() - start

    let text = `📊 *BOT STATUS*

⚡ Response : ${latency.toFixed(2)} ms
⏱ Runtime  : ${runtime(process.uptime())}

💾 *RAM*
${formatSize(os.totalmem() - os.freemem())} / ${formatSize(os.totalmem())}

🧠 *NodeJS Memory*
${Object.entries(used).map(([k, v]) => `- ${k}: ${formatSize(v)}`).join('\n')}
`

    if (cpus[0]) {
        text += `

🖥 *CPU*
${cpus[0].model}
Speed : ${cpu.speed.toFixed(0)} MHz
Cores : ${cpus.length}

${Object.keys(cpu.times)
    .map(t => `- ${t}: ${(100 * cpu.times[t] / cpu.total).toFixed(2)}%`)
    .join('\n')}
`
    }

    reply(text.trim())
}
break
            default:
        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
