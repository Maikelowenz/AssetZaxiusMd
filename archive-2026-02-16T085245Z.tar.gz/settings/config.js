const fs = require('fs')

const config = {
    owner: "-",
    botNumber: "-",
    setPair: "RENJIIII",
    thumbUrl: "https://api.deline.web.id/M8TgbiUftL.jpg",
    session: "sessions",
    status: {
        public: true,
        terminal: true,
        reactsw: false
    },
    message: {
        owner: "no, this is for owners only",
        group: "this is for groups only",
        admin: "this command is for admin only",
        private: "this is specifically for private chat"
    },
    settings: {
        title: "w-shennmine",
        packname: 'laurine-wabot',
        description: "this script was created by Renjii",
        author: 'https://www.Renn.tech',
        footer: "shenń, yes"
    },
    newsletter: {
        name: "Renjii-wb",
        id: "@newsletter"
    },
    socialMedia: {
        YouTube: "https://..",
        GitHub: "https://..r",
        Telegram: "https://..",
        ChannelWA: "https://.."
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
